import player from './red.png';
import gen3inside from './gen3_inside.png';
import gen3outside from './gen3_outside.png';

export {
    gen3inside,
    gen3outside,
    player
};
