import Phaser from 'phaser';
import {PalletMap, TestMap} from '@Maps';
import {gen3inside, gen3outside} from '@Tileset';
import {Player} from '@Objects';

export default class HeroHouseF1 extends Phaser.Scene {
  constructor() {
    super({ key: 'HeroHouseF1' });
  }

  preload () {
    this.load.image('gen3_outside', gen3outside);
    this.load.tilemapTiledJSON('test', TestMap);
    this.load.spritesheet('red', '../tileset/red.png', {
      frameWidth: 32,
      frameHeight: 40,
    });
  }

  create () {
    const map = this.make.tilemap({key: 'test'});
    var mapTileset = map.addTilesetImage('gen3_outside', 'gen3_outside');


    const floorLayer = map.createLayer('floor', mapTileset);
    const groundLayer = map.createLayer('ground', mapTileset);
    const topLayer = map.createLayer('top', mapTileset);
    const animLayer = map.createLayer('animation', mapTileset);

    this.player = new Player(this, 8, 6, 'red', map);

    PhaserGUIAction(this);
  }

  update() {
    const cursors = this.input.keyboard.createCursorKeys();
    this.player.update(cursors);
  }
}
