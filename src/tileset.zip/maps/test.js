import Phaser from 'phaser';
import {PalletMap, TestMap} from '@Maps';
import {gen3inside, gen3outside} from '@Tileset';
import {Player} from '@Objects';

export default class TestScene extends Phaser.Scene {
  constructor() {
    super({ key: 'TestScene' });
  }

  preload () {
    // this.load.image('gen3_inside', gen3inside);
    this.load.image('gen3_outside', gen3outside);
    this.load.tilemapTiledJSON('test', TestMap);
    this.load.spritesheet('red', '../tileset/red.png', {
      frameWidth: 32,
      frameHeight: 40,
    });
  }

  create () {
    const map = this.make.tilemap({key: 'test'});
    var mapTileset = map.addTilesetImage('gen3_outside', 'gen3_outside');


    const floorLayer = map.createLayer('floor', mapTileset);
    const groundLayer = map.createLayer('ground', mapTileset);
    const topLayer = map.createLayer('top', mapTileset);
    const animLayer = map.createLayer('animation', mapTileset);

    this.player = new Player(this, 36, 6, 'red', map);

    PhaserGUIAction(this);
  }

  update() {
    const cursors = this.input.keyboard.createCursorKeys();
    this.player.update(cursors);
  }
}
