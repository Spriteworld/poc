import PalletMap from './pallet.json';
import TestMap from './test.json';
import TestScene from './test.js';
import HeroHouseF1 from './hero_house_floor1.js';
// import HeroHouseF2 from './hero_house_floor2.js';

export {PalletMap, TestMap, TestScene, HeroHouseF1};
